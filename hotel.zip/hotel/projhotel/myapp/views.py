from django.shortcuts import render
from django.http import HttpResponse
from django.conf import settings
from django.core.mail import send_mail
from .models import Contact,Registration
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login


# Create your views here.
def index(request):
    return render(request,'index.html',{})
def about(request):
    return render(request,'about.html',{})
def contact(request):
    return render(request,'contact.html',{})
def gallery(request):
    return render(request,'gallery.html',{})
def reservation(request):
    return render(request,'reservation.html',{})
def room(request):
    return render(request,'room.html',{})
def staff(request):
    allStaff= Registration.getAllMember()
    data={}
    data['staff1']=allStaff
    return render(request,'staff.html',data)


def contactData(request):
    name= request.POST.get('name','default')
    print(name)
    mobile= request.POST.get('mobile','default')
    print(mobile)
    email= request.POST.get('email','default')
    print(email)
    subject= request.POST.get('subject','default')
    print(subject)
    msg= request.POST.get('msg','default')
    print(msg)

    S = Contact(Name=name,Mobile=mobile,Email=email,Subject=subject,Msg=msg)
    S.save()

    return HttpResponse('Data is saved Successfully.')

def ReservationData(request):
    name= request.POST.get('name','default')
    print(name)
    mobile= request.POST.get('mobile','default')
    print(mobile)
    email= request.POST.get('email','default')
    print(email)
    checkin= request.POST.get('checkin','default')
    print(checkin)
    checkout= request.POST.get('checkout','default')
    print(checkout)
    adults= request.POST.get('adults','default')
    print(adults)
    children= request.POST.get('children','default')
    print(children)
    roomtypes= request.POST.get('roomtype','default')
    print(roomtypes)
    noofrooms= request.POST.get('noofrooms','default')
    print(noofrooms)

    subject = 'welcome to Skyline hotel'
    message = f'yes,there is a slot available for you.'
    email_from = settings.EMAIL_HOST_USER
    recipient_list = ['sajalarora1996@gmail.com', 'priyachugh8439@gmail.com','prabhatsolanki099@gmail.com']
    send_mail( subject, message, email_from, recipient_list )


    return HttpResponse("Your Reservation is successfully done.")

def login(request):
    return render(request,'login.html',{})
def signup(request):
    return render(request,'signup.html',{})


def LoginData(request):
    if request.method == 'POST':

        username=request.POST['username']
        password=request.POST['password']
        print(username,password)
        user= authenticate(username=username,password=password)
        if user is not None:
            login(request)
            return render(request,'index.html')
        else:
             return HttpResponse("Invalid Username Password or The Username doesn't exists.")

    
def SignupData(request):
    firstname= request.POST.get('firstname','default')
    print(firstname)
    lastname= request.POST.get('lastname','default')
    print(lastname)
    email= request.POST.get('email','default')
    print(email)
    password= request.POST.get('pass','default')
    print(password)

    username_exist=User.objects.filter(username=firstname)
    if username_exist:
        return HttpResponse("This username already exists, Please enter any other username")
    else:
        user=User.objects.create(username=firstname, last_name=lastname,email=email, password=password)
        user.set_password(password)
        user.save()
        return render(request,'login.html',{})
    

