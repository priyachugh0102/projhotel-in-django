from django.db import models

# Create your models here.

class Contact(models.Model):
    Name = models.CharField(max_length=100)
    Mobile = models.IntegerField()
    Email = models.EmailField()
    Subject = models.CharField(max_length=100)
    Msg = models.TextField()

class Registration(models.Model):
    CandidateName = models.CharField(max_length=100)
    RollNo = models.IntegerField()
    Contact = models.IntegerField()
    Email = models.EmailField()
    # Image = models.ImageField(upload_to='myimage')
    
    @staticmethod
    def getAllMember():
        return Registration.objects.all()
